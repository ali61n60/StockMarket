/*
 * TFT_MENU.h
 *
 *  Created on: Nov 13, 2020
 *      Author: meh
 */

#ifndef INC_TFT_MENU_H_
#define INC_TFT_MENU_H_

void HomeMenu (void);
void TestMenu (void);
void Page2Menu (void);

void Menu_Handler (void);


#endif /* INC_TFT_MENU_H_ */
